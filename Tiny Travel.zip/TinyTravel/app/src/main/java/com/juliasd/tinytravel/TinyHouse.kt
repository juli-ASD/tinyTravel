package com.juliasd.tinytravel

data class TinyHouse(val image: String, val name: String, val city: String, val description: String, val priceDay: String, val priceWeek: String)