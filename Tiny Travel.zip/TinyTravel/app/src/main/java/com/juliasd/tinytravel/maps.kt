package com.juliasd.tinytravel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class maps : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
    }
}